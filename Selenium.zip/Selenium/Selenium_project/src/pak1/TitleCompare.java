package pak1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TitleCompare {
static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) 
	{
	
	// 1.Launch Browser
	System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	driver.get("file:///D:/Participants%20Material/Module%204/Demos/Lesson%202%20-%20Demos/HTML%20Pages/LocatingElements.html");
	
	/*String expectedtitle = "Employee detail";
	String actualtitle = driver.getTitle();
	System.out.println(actualtitle);
	//System.out.println(expectedtitle.equals(actualtitle));
	if(expectedtitle.equals(actualtitle))
		{
		System.out.println("Title Matching");
		}
	else
		{
		System.out.println("Title Not Matching");
		}
	*/
	
	boolean title = driver.getTitle().contains("Employee detail");
	System.out.println(title);
	
	System.out.println(driver.getCurrentUrl());
	System.out.println(driver.getPageSource());
	boolean txt = driver.getPageSource().contains("alert");
	System.out.println(txt);
	WebElement wb = driver.findElement(By.xpath("//h3"));
	String htxt = wb.getText();
	System.out.println(htxt);
	boolean res = htxt.equals("Refer Your Friend");
	System.out.println(res);
	
	/**************Get Attribute*********************/
	driver.findElement(By.id("FN")).sendKeys("Priyal");
	
	String str1 = driver.findElement(By.id("FN")).getAttribute("type");
	String str2 = driver.findElement(By.id("FN")).getAttribute("value");
	System.out.println(str1);
	System.out.println(str2);
	driver.close();
	
	}	
}
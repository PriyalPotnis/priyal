package pak1;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class AllLocators {
	public static void main(String[] args) throws InterruptedException 
	{
		
	
	// 1.Launch Browser
	WebDriver driver = new FirefoxDriver();
	
	// 2.Navigate to URL
	driver.get("file:///D:/Participants%20Material/Module%204/Demos/Lesson%202%20-%20Demos/HTML%20Pages/LocatingElements.html");
	
	// 3. Select value from Drop down
		//1. Find drop down
	
	driver.findElement(By.cssSelector("input#FN")).sendKeys("Priyal");
	Thread.sleep(1000);
	driver.findElement(By.name("mname")).sendKeys("Bipin");
	Thread.sleep(1000);
	driver.findElement(By.id("LN")).sendKeys("Potnis");
	Thread.sleep(1000);
	driver.findElement(By.className("Format")).sendKeys("17/05/1995");
	Thread.sleep(1000);
	driver.findElement(By.name("contact_no")).sendKeys("9170519950");
	Thread.sleep(1000);
	driver.findElement(By.cssSelector("input.EmailFormat[name='email']")).sendKeys("priyal@gmail.com");
	Thread.sleep(1000);
	driver.findElement(By.id("PNO")).sendKeys("R2328934");
	Thread.sleep(1000);
	WebElement wb1 = driver.findElement(By.id("country"));
	//create an obj of select class
	Select sel = new Select(wb1);
	//select value form drop down
	//sel.selectByVisibleText("USA");
	sel.selectByValue("USA");
	//sel.selectByIndex(3);
	Thread.sleep(1000);
	WebElement wb2 = driver.findElement(By.id("city_input"));
	Thread.sleep(1000);
	
	Select sel1 = new Select(wb2);
	sel1.selectByIndex(3);
	sel.selectByVisibleText("USA");
	driver.findElement(By.xpath("//input[@value='male']")).click();
	Thread.sleep(1000);
	driver.findElement(By.xpath("//input[@name='total_exp']")).sendKeys("3");
	Thread.sleep(1000);
	driver.findElement(By.name("relv_exp")).sendKeys("2");
	Thread.sleep(1000);
	driver.findElement(By.name("present_emp")).sendKeys("Gowtham");
	Thread.sleep(1000);
	
	WebElement wb3 = driver.findElement(By.name("relation"));
	Select sel2 = new Select(wb3);
	
	sel2.selectByIndex(2);
	driver.findElement(By.name("resume")).sendKeys("Priyal Potnis \nHobbies: Sleeping \nEducation : Laziness Academy");
	driver.findElement(By.cssSelector("input[value='Preview']")).click();
	Thread.sleep(1000);
	
	driver.findElement(By.name("submit")).submit();
	
	
	}
}


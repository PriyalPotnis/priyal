package pak1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.ie.InternetExplorerDriver;

public class Sel_class1
{
static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
//static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\selenium-2.43.1\\";
	public static void main(String[] args) 
	{
	
	// 1.Launch Browser
		
	/***************** For Internet Explorer ****************
		System.setProperty("webdriver.ie.driver", driverpath+ "IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();*/
	
	/********************For Chrome Browser*********************/
	System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	/*************** For Fire Fox Browser ******************
	WebDriver driver = new FirefoxDriver();*/
	
	// 2.Navigate to URL
	driver.get("file:///D:/Participants%20Material/Module%204/Demos/Lesson%205-HTML%20Pages/WorkingWithForms.html");
	
	// 3. Enter Username
	
	
	}

}

package pak1;

public class Main1 {
Sample s = new Sample();
}

package testNGdemoPak;

import org.testng.annotations.Test;

public class TestNGdemo1 {
	
 @Test
 public void Login(){
	 System.out.println("Login to the application");
 }
 @Test
 public void Delete(){
	 System.out.println("Deleting the result");
 }
}

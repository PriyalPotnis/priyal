package lab;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab4_Validation {

	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		// 1.Launch Browser
		System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.opencart.com/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.id("input-email")).sendKeys("priyal20@gmail.com");
		driver.findElement(By.id("input-password")).sendKeys("priyal123");
		driver.findElement(By.cssSelector("input[value='Login']")).click();
		driver.findElement(By.linkText("Components")).click();
		driver.findElement(By.linkText("Monitors (2)")).click();
		WebElement wb = driver.findElement(By.id("input-limit"));
		Select s = new Select(wb);
		s.selectByVisibleText("25");
		driver.findElement(By.linkText("Add to Cart")).click();
		
	}

}

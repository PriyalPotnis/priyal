package lab;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class lab3_Create_Accnt {
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
/******************---PART 1---*********************************************/
		// 1.Launch Browser
		System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		//WebDriver driver = new FirefoxDriver();
		driver.get("https://demo.opencart.com/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Register")).click();
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
		
		//To Validate Error Message
		WebElement wb = driver.findElement(By.xpath("//*[@id='account-register']/div[1]"));
		String htxt = wb.getText();
		System.out.println(htxt);
		boolean res = htxt.equals("Warning: You must agree to the Privacy Policy!");
		System.out.println(res);
		
		driver.findElement(By.name("agree")).click();
		//Thread.sleep(1000);
		/******************---PART 2---*********************************************/
		
		driver.findElement(By.id("input-firstname")).sendKeys("abcdefghijklmnopqrstuvwxyz1234567");
		//Thread.sleep(1000);
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
				
		driver.findElement(By.id("input-lastname")).sendKeys("abcdefghijklmnopqrstuvwxyz1234567");
		//Thread.sleep(1000);
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
		
		driver.findElement(By.linkText("Register")).click();
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Priyal");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='input-lastname']")).sendKeys("Potnis");
		//Thread.sleep(2000);
		driver.findElement(By.id("input-email")).sendKeys("priyal20@gmail.com");
		//driver.findElement(By.cssSelector("input[value='Continue']")).click();
		//Thread.sleep(2000);
		
		driver.findElement(By.name("telephone")).sendKeys("9170519950");
		//driver.findElement(By.cssSelector("input[value='Continue']")).click();
		//Thread.sleep(2000);
		
		driver.findElement(By.id("input-password")).sendKeys("priyal123");
		//Thread.sleep(2000);
		driver.findElement(By.cssSelector("input#input-confirm")).sendKeys("priyal123");
		//Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id='content']/form/fieldset[3]/div/div/label[1]/input")).click();
		//Thread.sleep(2000);
		driver.findElement(By.name("agree")).click();
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
//		WebElement wb2 = driver.findElement(By.xpath("//h1"));
//		String htxt2 = wb2.getText();
//		System.out.println(htxt);
//		boolean res2 = htxt2.equals("Your Account Has Been Created!");
//		System.out.println(res2);
		//
		//driver.close();
		WebElement wb2 = driver.findElement(By.xpath("//*[@id='content']/h1"));
		String expectedtitle = "Your Account Has Been Created!";
		String actualtitle = wb2.getText();
		System.out.println(actualtitle);
		System.out.println(expectedtitle.equals(actualtitle));
		driver.navigate().to("https://demo.opencart.com/index.php?route=account/account");
		
		driver.navigate().to("https://demo.opencart.com/index.php?route=account/order");
	}

	
}
